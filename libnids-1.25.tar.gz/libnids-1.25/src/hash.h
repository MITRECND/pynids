void init_hash();
u_int
mkhash (u_int , u_short , u_int , u_short);
